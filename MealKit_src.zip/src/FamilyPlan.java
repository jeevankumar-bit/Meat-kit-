import java.util.List;

/** Family plan - bulk pricing, free delivery. */
public class FamilyPlan extends Plan {
    private int familySize;

    public FamilyPlan(int planId, int mealsPerWeek, double pricePerMeal, int familySize, List<String> cuisinePrefs) {
        super(planId, "Family Plan", mealsPerWeek, pricePerMeal, cuisinePrefs);
        this.familySize = familySize;
    }

    public int getFamilySize() { return familySize; }

    @Override
    public double computeTotal(int meals) {
        return meals * getPricePerMeal() * familySize * 0.85; // 15% bulk discount
    }

    @Override
    public double deliveryFee() {
        return 0.0; // free delivery
    }
}
