import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A weekly order. State (status, meals, total) is encapsulated and only changed via methods. */
public class Order {
    public enum Status { CREATED, DISPATCHED, DELIVERED }

    private int orderId;
    private Subscriber subscriber;
    private int weekOfYear;
    private List<String> selectedMeals;   // private - protected from outside changes
    private int totalPortions;
    private Status status;
    private double total;
    private double discount;

    public Order(int orderId, Subscriber subscriber, int weekOfYear) {
        this.orderId = orderId;
        this.subscriber = subscriber;
        this.weekOfYear = weekOfYear;
        this.selectedMeals = new ArrayList<>();
        this.totalPortions = 0;
        this.status = Status.CREATED;
        this.total = 0;
        this.discount = 0;
    }

    public int getOrderId() { return orderId; }
    public Subscriber getSubscriber() { return subscriber; }
    public int getWeekOfYear() { return weekOfYear; }
    public Status getStatus() { return status; }
    public double getTotal() { return total; }
    public List<String> getSelectedMeals() { return Collections.unmodifiableList(selectedMeals); }

    /** Overload 1: add a meal by id (1 portion). */
    public boolean addMeal(String mealId) {
        return addMeal(mealId, 1);
    }

    /** Overload 2: add a meal by id and portion size. */
    public boolean addMeal(String mealId, int portionSize) {
        if (status != Status.CREATED) {
            System.out.println("  ! Order #" + orderId + " is " + status + " - cannot add meals.");
            return false;
        }
        if (portionSize <= 0) return false;
        for (int i = 0; i < portionSize; i++) selectedMeals.add(mealId);
        totalPortions += portionSize;
        recalculate();
        return true;
    }

    public boolean removeMeal(String mealId) {
        if (status == Status.CREATED && selectedMeals.remove(mealId)) {
            totalPortions--;
            recalculate();
            return true;
        }
        return false;
    }

    /** Polymorphic call: the subscriber's plan decides the pricing rule. */
    private void recalculate() {
        Plan plan = subscriber.getActivePlan();
        total = plan.computeTotal(totalPortions) + plan.deliveryFee() - discount;
        if (total < 0) total = 0;
    }

    /** Applies a coupon code: WELCOME10 = 10% off, FLAT50 = Rs.50 off. */
    public boolean applyCoupon(String code) {
        if (status != Status.CREATED || discount > 0) return false;
        double base = total;
        switch (code) {
            case "WELCOME10": discount = base * 0.10; break;
            case "FLAT50":    discount = 50.0; break;
            default:
                System.out.println("  ! Invalid coupon: " + code);
                return false;
        }
        recalculate();
        return true;
    }

    public boolean dispatch() {
        if (status == Status.CREATED && !selectedMeals.isEmpty()) {
            status = Status.DISPATCHED;
            return true;
        }
        return false;
    }

    public boolean markDelivered() {
        if (status == Status.DISPATCHED) {
            status = Status.DELIVERED;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return String.format("Order#%d | Week %d | %s | Meals: %d | Total: Rs.%.2f | %s",
                orderId, weekOfYear, subscriber.getName(), selectedMeals.size(), total, status);
    }
}
