import java.util.List;

/** Vegetarian plan - discounted meals, standard delivery fee. */
public class VegPlan extends Plan {
    public VegPlan(int planId, int mealsPerWeek, double pricePerMeal, List<String> cuisinePrefs) {
        super(planId, "Veg Plan", mealsPerWeek, pricePerMeal, cuisinePrefs);
    }

    @Override
    public double computeTotal(int meals) {
        return meals * getPricePerMeal() * 0.95; // 5% veg discount
    }

    @Override
    public double deliveryFee() {
        return 40.0;
    }
}
