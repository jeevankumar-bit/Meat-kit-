import java.util.ArrayList;
import java.util.List;

/** Base class for all subscription plans. */
public class Plan {
    private int planId;
    private String name;
    private int mealsPerWeek;
    private double pricePerMeal;
    private List<String> cuisinePrefs;

    public Plan(int planId, String name, int mealsPerWeek, double pricePerMeal, List<String> cuisinePrefs) {
        this.planId = planId;
        this.name = name;
        this.mealsPerWeek = mealsPerWeek;
        this.pricePerMeal = pricePerMeal;
        this.cuisinePrefs = new ArrayList<>(cuisinePrefs);
    }

    public int getPlanId() { return planId; }
    public String getName() { return name; }
    public int getMealsPerWeek() { return mealsPerWeek; }
    public double getPricePerMeal() { return pricePerMeal; }
    public List<String> getCuisinePrefs() { return new ArrayList<>(cuisinePrefs); }
    public void setPricePerMeal(double pricePerMeal) { this.pricePerMeal = pricePerMeal; }
    public void addCuisinePref(String cuisine) { cuisinePrefs.add(cuisine); }

    /** Default total: meals x price per meal. Overridden by sub-plans. */
    public double computeTotal(int meals) {
        return meals * pricePerMeal;
    }

    /** Default delivery fee. Overridden by sub-plans. */
    public double deliveryFee() {
        return 50.0;
    }

    @Override
    public String toString() {
        return name + " [" + mealsPerWeek + " meals/week @ Rs." + pricePerMeal + "]";
    }
}
