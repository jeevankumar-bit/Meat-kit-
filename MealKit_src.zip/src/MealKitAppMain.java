import java.util.*;

public class MealKitAppMain {
    public static void main(String[] args) {
        MealKitService service = new MealKitService();
        service.createMenu();
        service.printMenu();

        // Plans (Inheritance)
        Plan veg = new VegPlan(1, 4, 200, Arrays.asList("South Indian", "Italian"));
        Plan nonVeg = new NonVegPlan(2, 5, 250, Arrays.asList("North Indian", "Seafood"));
        Plan family = new FamilyPlan(3, 6, 180, 4, Arrays.asList("Indian"));

        // Subscribers
        Subscriber s1 = new Subscriber(1, "Jeevan", "jeevan@mail.com", "12 Gandhi St, Coimbatore", veg);
        Subscriber s2 = new Subscriber(2, "Priya", "priya@mail.com", "45 Anna Nagar, Chennai", nonVeg);
        Subscriber s3 = new Subscriber(3, "Kumar", "kumar@mail.com", "7 Lake View, Madurai", family);

        System.out.println("\n---- Subscribers ----");
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);

        // Polymorphism: totals for different plans
        System.out.println();
        service.printPlanTotals(Arrays.asList(veg, nonVeg, family));

        // Build weekly orders (Method Overloading)
        int week = 44;
        System.out.println("\n---- Building weekly orders ----");
        Order o1 = service.generateOrder(s1, week);
        o1.addMeal("M01");
        o1.addMeal("M02", 2);
        o1.addMeal("M05");

        Order o2 = service.generateOrder(s2, week);
        o2.addMeal("M03", 3);
        o2.addMeal("M04");

        Order o3 = service.generateOrder(s3, week);
        o3.addMeal("M01", 2);
        o3.addMeal("M02", 2);
        o3.addMeal("M03", 2);

        for (Order o : service.getOrders()) System.out.println(o);

        // Substitution
        System.out.println("\n---- Substitution ----");
        boolean sub = service.substituteMeal(o2, "M04", "M06");
        System.out.println("Substitute M04 -> M06 in Order#" + o2.getOrderId() + ": " + sub);
        System.out.println(o2);

        // Coupons
        System.out.println("\n---- Apply coupons ----");
        System.out.println("WELCOME10 on Order#" + o1.getOrderId() + ": " + o1.applyCoupon("WELCOME10"));
        System.out.println("FLAT50 on Order#" + o2.getOrderId() + ": " + o2.applyCoupon("FLAT50"));
        System.out.println("BADCODE on Order#" + o3.getOrderId() + ": " + o3.applyCoupon("BADCODE"));

        // Schedule + dispatch
        System.out.println("\n---- Delivery scheduling & dispatch ----");
        service.scheduleDelivery(o1, "Mon 9AM-12PM");
        service.scheduleDelivery(o2, "Tue 2PM-5PM");
        service.scheduleDelivery(o3, "Wed 10AM-1PM");
        for (Order o : service.getOrders())
            System.out.println("Dispatch Order#" + o.getOrderId() + ": " + o.dispatch());

        // Encapsulation check: cannot modify after dispatch
        System.out.println("\n---- Encapsulation check ----");
        o1.addMeal("M03");

        // Mark delivered
        System.out.println("\n---- Mark delivered ----");
        System.out.println("Deliver Order#" + o1.getOrderId() + ": " + o1.markDelivered());
        System.out.println("Deliver Order#" + o2.getOrderId() + ": " + o2.markDelivered());
        System.out.println("Deliver Order#" + o3.getOrderId() + ": " + o3.markDelivered());

        System.out.println("\n---- Final order status ----");
        for (Order o : service.getOrders()) System.out.println(o);

        // Reports
        System.out.println();
        service.printWeeklyRevenue(week);
        System.out.println();
        service.printMealPopularity();
    }
}
