/** A customer subscribed to the meal kit service. */
public class Subscriber {
    private int id;
    private String name;
    private String email;
    private String deliveryAddress;
    private Plan activePlan;

    public Subscriber(int id, String name, String email, String deliveryAddress, Plan activePlan) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.deliveryAddress = deliveryAddress;
        this.activePlan = activePlan;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public Plan getActivePlan() { return activePlan; }
    public void setDeliveryAddress(String deliveryAddress) { this.deliveryAddress = deliveryAddress; }
    public void changePlan(Plan newPlan) { this.activePlan = newPlan; }
    public boolean hasActivePlan() { return activePlan != null; }

    @Override
    public String toString() {
        return "Subscriber#" + id + " " + name + " <" + email + "> Plan: " + activePlan.getName();
    }
}
