import java.util.*;

/** Handles menu creation, order generation, substitutions and delivery scheduling. */
public class MealKitService {
    private Map<String, String> menu;                 // mealId -> meal name
    private List<Order> orders;
    private Map<Integer, String> deliverySchedule;    // orderId -> slot
    private int nextOrderId;

    public MealKitService() {
        this.menu = new LinkedHashMap<>();
        this.orders = new ArrayList<>();
        this.deliverySchedule = new HashMap<>();
        this.nextOrderId = 1001;
    }

    public void createMenu() {
        menu.put("M01", "Paneer Butter Masala Kit");
        menu.put("M02", "Veg Biryani Kit");
        menu.put("M03", "Chicken Curry Kit");
        menu.put("M04", "Fish Fry Kit");
        menu.put("M05", "Pasta Primavera Kit");
        menu.put("M06", "Mutton Pepper Fry Kit");
    }

    public void printMenu() {
        System.out.println("---- Weekly Menu ----");
        for (Map.Entry<String, String> e : menu.entrySet())
            System.out.println(e.getKey() + " : " + e.getValue());
    }

    public Order generateOrder(Subscriber s, int week) {
        Order o = new Order(nextOrderId++, s, week);
        orders.add(o);
        return o;
    }

    /** Replace one meal with another in an order that is not yet dispatched. */
    public boolean substituteMeal(Order o, String oldMeal, String newMeal) {
        if (!menu.containsKey(newMeal)) return false;
        if (o.removeMeal(oldMeal)) {
            return o.addMeal(newMeal);
        }
        return false;
    }

    public void scheduleDelivery(Order o, String slot) {
        deliverySchedule.put(o.getOrderId(), slot);
        System.out.println("Order #" + o.getOrderId() + " scheduled for " + slot
                + " at " + o.getSubscriber().getDeliveryAddress());
    }

    /** Polymorphism: same call, different pricing for each Plan subtype. */
    public void printPlanTotals(List<Plan> plans) {
        System.out.println("---- Plan totals (full week) ----");
        for (Plan p : plans) {
            double t = p.computeTotal(p.getMealsPerWeek()) + p.deliveryFee();
            System.out.printf("%-14s meals=%d  delivery=Rs.%.2f  total=Rs.%.2f%n",
                    p.getName(), p.getMealsPerWeek(), p.deliveryFee(), t);
        }
    }

    public void printWeeklyRevenue(int week) {
        double revenue = 0;
        for (Order o : orders)
            if (o.getWeekOfYear() == week && o.getStatus() == Order.Status.DELIVERED)
                revenue += o.getTotal();
        System.out.printf("Week %d revenue (delivered orders): Rs.%.2f%n", week, revenue);
    }

    public void printMealPopularity() {
        Map<String, Integer> count = new TreeMap<>();
        for (Order o : orders)
            for (String m : o.getSelectedMeals())
                count.merge(m, 1, Integer::sum);
        System.out.println("---- Meal Popularity Report ----");
        count.entrySet().stream()
             .sorted((a, b) -> b.getValue() - a.getValue())
             .forEach(e -> System.out.println(menu.get(e.getKey()) + " (" + e.getKey() + ") -> "
                     + e.getValue() + " portions"));
    }

    public List<Order> getOrders() { return new ArrayList<>(orders); }
}
