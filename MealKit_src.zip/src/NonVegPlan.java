import java.util.List;

/** Non-vegetarian plan - premium ingredients surcharge. */
public class NonVegPlan extends Plan {
    public NonVegPlan(int planId, int mealsPerWeek, double pricePerMeal, List<String> cuisinePrefs) {
        super(planId, "Non-Veg Plan", mealsPerWeek, pricePerMeal, cuisinePrefs);
    }

    @Override
    public double computeTotal(int meals) {
        return meals * getPricePerMeal() * 1.10; // 10% premium surcharge
    }

    @Override
    public double deliveryFee() {
        return 60.0;
    }
}
